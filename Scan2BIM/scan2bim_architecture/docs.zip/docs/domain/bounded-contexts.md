# Scan2BIM Bounded Contexts

Version: 1.0

Status: Accepted

Owner: Ajeesh Kumar A

Related Documents

- Vision.md
- ADR-001 Technology Constitution
- DomainModel.md

---

# 1. Purpose

This document defines the bounded contexts of the Scan2BIM Platform.

Bounded contexts establish:

- Business ownership boundaries
- Service ownership boundaries
- Domain ownership
- Event ownership
- Future microservice boundaries

The purpose is to ensure that responsibilities remain clearly separated and that services evolve independently without creating tight coupling.

---

# 2. Architectural Principle

The Scan2BIM Platform follows:

- Domain Driven Design
- Microservices Architecture
- Event Driven Architecture
- Ingestion First Architecture
- Channel Independent Ingestion
- Workflow-Orchestrated Processing

Each bounded context owns its business capabilities, data, events, and contracts.

No bounded context may directly own or modify another context's internal state.

Communication between contexts shall occur only through approved contracts, APIs, workflow commands, or events.

Direct database sharing between bounded contexts is not permitted.

---

# 3. Context Overview

The platform consists of the following bounded contexts:

1. Project Context
2. Ingestion Context
3. Workflow Context
4. Segmentation Context
5. Geometry Context
6. IFC Context
7. Delivery Context

The Upload Portal is not a bounded context.

The Upload Portal is a client application that interacts with the Ingestion Context.

---

# 4. Project Context

## Purpose

The Project Context owns customer, project, and site information.

It represents the business-level organization of Scan2BIM work.

---

## Owned Entities

- Project
- Site

---

## Responsibilities

- Project lifecycle management
- Site registration
- Site metadata management
- Project ownership
- Customer or engagement-level grouping
- Business-level reporting support

---

## Does NOT Own

- Ingestion requests
- Point cloud files
- Workflow execution
- Segmentation processing
- Geometry extraction
- IFC generation
- Artifact delivery

---

## Publishes Events

Examples:

- ProjectCreated
- ProjectUpdated
- SiteCreated
- SiteUpdated

---

## Consumes Events

Examples:

- WorkflowCompleted
- ArtifactDelivered

These consumed events may be used for reporting or business-level visibility only.

---

# 5. Ingestion Context

## Purpose

The Ingestion Context owns onboarding of scan data into the Scan2BIM Platform.

This is the single normalized entry point into the platform.

All incoming scan data must pass through the Ingestion Context before workflow execution begins.

---

## Owned Entities

- IngestionRequest
- PointCloudFile

---

## Supported Ingestion Channels

- Scan2BIM Upload Portal
- External Customer Portal
- REST API
- Webhook
- Bulk Upload Utility
- Future Automated Sources

---

## Responsibilities

- File upload acceptance
- Webhook-based intake
- File validation
- Metadata capture
- Artifact registration
- Storage registration
- Ingestion status tracking
- Source channel normalization
- Ingestion audit capture

---

## Does NOT Own

- Workflow execution
- Temporal orchestration
- Segmentation algorithms
- Geometry extraction
- IFC generation
- Artifact delivery

---

## Publishes Events

Examples:

- IngestionRequested
- FileUploaded
- IngestionValidated
- IngestionFailed
- PointCloudFileRegistered

---

## Consumes Events

Examples:

- None for the MVP baseline

The Ingestion Context is primarily an entry context.

---

## Important Rule

Workflow initiation shall occur only after successful ingestion validation and artifact registration.

Downstream services shall remain independent of whether the input came from:

- Scan2BIM Upload Portal
- External Portal
- REST API
- Webhook
- Future Automated Source

---

# 6. Workflow Context

## Purpose

The Workflow Context owns orchestration and lifecycle management of Scan2BIM processing activities.

This context coordinates processing.

It does not perform segmentation, geometry extraction, IFC generation, or artifact delivery logic itself.

---

## Owned Entities

- Workflow

---

## Responsibilities

- Workflow creation
- Workflow status tracking
- Processing coordination
- Retry coordination
- Failure handling
- Compensation coordination
- Progress tracking
- Workflow completion tracking

---

## Does NOT Own

- Point cloud file storage
- Segmentation algorithms
- Geometry extraction logic
- IFC generation logic
- Artifact delivery logic

---

## Publishes Events

Examples:

- WorkflowStarted
- WorkflowStepStarted
- WorkflowStepCompleted
- WorkflowCompleted
- WorkflowFailed
- WorkflowCancelled

---

## Consumes Events

Examples:

- IngestionValidated
- SegmentationCompleted
- SegmentationFailed
- GeometryGenerated
- GeometryGenerationFailed
- IFCGenerated
- IFCGenerationFailed
- ArtifactDelivered

---

## Important Rule

The Workflow Context orchestrates the processing lifecycle but does not implement processing logic.

It coordinates work across other contexts through approved commands, events, and workflow activities.

---

# 7. Segmentation Context

## Purpose

The Segmentation Context owns semantic interpretation of point cloud data.

It transforms point cloud data into segmentation results that identify meaningful objects and classes within scan data.

---

## Owned Entities

- SegmentationResult

---

## Responsibilities

- Point cloud segmentation
- Semantic classification
- Model inference execution
- Class detection
- Confidence metric generation
- Segmentation artifact creation
- Segmentation failure reporting

---

## Business Objects Identified

Examples:

- Wall
- Door
- Floor
- Ceiling
- Rack
- Cabinet
- Battery Cabinet
- Battery
- Rectifier

---

## Does NOT Own

- Ingestion
- Workflow orchestration
- Geometry extraction
- IFC generation
- Artifact delivery

---

## Publishes Events

Examples:

- SegmentationStarted
- SegmentationCompleted
- SegmentationFailed
- SegmentationResultGenerated

---

## Consumes Events

Examples:

- SegmentationRequested

---

## Important Rule

The Segmentation Context produces semantic classification outputs.

It does not create BIM-ready geometry and does not generate IFC outputs.

---

# 8. Geometry Context

## Purpose

The Geometry Context owns transformation of segmentation results into structured geometry models.

It converts segmentation outputs into BIM-ready geometric representations.

---

## Owned Entities

- GeometryModel

---

## Responsibilities

- Geometry extraction
- Object boundary extraction
- Spatial relationship extraction
- Shape reconstruction
- BIM object preparation
- Geometry validation
- Geometry artifact generation

---

## Business Objects Modeled

Examples:

- Wall Geometry
- Door Geometry
- Floor Geometry
- Ceiling Geometry
- Rack Geometry
- Cabinet Geometry
- Battery Cabinet Geometry
- Battery Geometry
- Rectifier Geometry

---

## Does NOT Own

- Ingestion
- Workflow orchestration
- AI segmentation
- IFC generation
- Artifact delivery

---

## Publishes Events

Examples:

- GeometryExtractionStarted
- GeometryGenerated
- GeometryExtractionFailed
- GeometryModelCreated

---

## Consumes Events

Examples:

- SegmentationCompleted
- GeometryExtractionRequested

---

## Important Rule

The Geometry Context produces structured geometry models.

It does not perform semantic segmentation and does not generate IFC files.

---

# 9. IFC Context

## Purpose

The IFC Context owns generation of BIM deliverables.

It transforms geometry models into interoperable IFC outputs.

---

## Owned Entities

- IFCModel

---

## Responsibilities

- IFC creation
- IFC validation
- IFC enrichment
- IFC output generation
- IFC artifact registration support
- BIM deliverable preparation

---

## Does NOT Own

- Ingestion
- Workflow orchestration
- Segmentation
- Geometry extraction
- Artifact delivery

---

## Publishes Events

Examples:

- IFCGenerationStarted
- IFCGenerated
- IFCValidationCompleted
- IFCGenerationFailed

---

## Consumes Events

Examples:

- GeometryGenerated
- IFCGenerationRequested

---

## Important Rule

The IFC Context owns BIM deliverable generation only.

It shall not contain segmentation logic or workflow orchestration logic.

---

# 10. Delivery Context

## Purpose

The Delivery Context owns delivery and access preparation for generated outputs.

It makes generated artifacts available to consumers through approved delivery channels.

---

## Owned Entities

- Artifact

---

## Responsibilities

- Artifact delivery preparation
- Download preparation
- Output publishing
- Delivery status tracking
- Consumer access support
- Artifact availability notification

---

## Supported Delivery Channels

- Portal Download
- REST API Download
- External Portal Delivery
- Future Delivery Methods

---

## Does NOT Own

- Ingestion
- Workflow orchestration
- Segmentation
- Geometry extraction
- IFC generation

---

## Publishes Events

Examples:

- ArtifactReady
- ArtifactDelivered
- ArtifactDownloadRequested
- ArtifactDeliveryFailed

---

## Consumes Events

Examples:

- IFCGenerated
- ArtifactDeliveryRequested

---

## Important Rule

The Delivery Context owns output availability and delivery concerns.

It does not generate IFC files or perform processing logic.

---

# 11. Context Relationships

The expected high-level flow is:

Project Context
      |
      v
Ingestion Context
      |
      v
Workflow Context
      |
      v
Segmentation Context
      |
      v
Geometry Context
      |
      v
IFC Context
      |
      v
Delivery Context

----

# 12. Microservice Alignment

The recommended service structure aligns directly to the bounded contexts:

- project-service
- ingestion-service
- workflow-service
- segmentation-service
- geometry-service
- ifc-service
- delivery-service

Implementation may evolve, but ownership boundaries defined by these contexts must remain stable.